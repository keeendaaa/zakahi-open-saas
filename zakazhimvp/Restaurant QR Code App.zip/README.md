
  # Restaurant QR Code App

  This is a code bundle for Restaurant QR Code App. The original project is available at https://www.figma.com/design/L3Zc2WRyz14rDIhZWW5vRs/Restaurant-QR-Code-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  
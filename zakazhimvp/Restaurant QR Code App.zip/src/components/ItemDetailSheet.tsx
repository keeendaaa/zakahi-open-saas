import { useState } from 'react';
import { MenuItem } from '../types';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { X, Plus } from 'lucide-react';
import { Button } from './ui/button';
import { Sheet, SheetContent } from './ui/sheet';

interface ItemDetailSheetProps {
  item: MenuItem;
  menuItems: MenuItem[];
  onClose: () => void;
  onAddToCart: (item: MenuItem) => void;
}

export default function ItemDetailSheet({
  item,
  menuItems,
  onClose,
  onAddToCart,
}: ItemDetailSheetProps) {
  const [showComposition, setShowComposition] = useState(false);

  // Find similar items in same category
  const similarItems = menuItems
    .filter(i => i.category === item.category && i.id !== item.id)
    .slice(0, 3);

  const handleAddToCart = () => {
    onAddToCart(item);
    onClose();
  };

  return (
    <Sheet open={true} onOpenChange={onClose}>
      <SheetContent 
        side="bottom" 
        className="h-[90vh] rounded-t-3xl p-0 overflow-y-auto"
      >
        <button
          onClick={onClose}
          className="absolute right-4 top-4 z-10 rounded-full bg-white/90 backdrop-blur-sm p-2 hover:bg-white transition-colors shadow-lg"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header with price and volume */}
        <div className="sticky top-0 z-10 bg-white/95 backdrop-blur-sm border-b border-gray-100 px-6 py-4 flex items-center justify-between">
          <button
            onClick={handleAddToCart}
            className="flex items-center gap-2 bg-blue-600 text-white rounded-full px-5 py-2.5 hover:bg-blue-700 transition-colors shadow-sm"
          >
            <Plus className="w-5 h-5" />
            <span>{item.price} ₽</span>
          </button>
          {item.volume && (
            <span className="text-gray-600">{item.volume}</span>
          )}
        </div>

        {/* Similar items horizontal scroll */}
        {similarItems.length > 0 && (
          <div className="px-6 py-4">
            <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
              {similarItems.map(similar => (
                <div
                  key={similar.id}
                  className="flex-shrink-0 w-72 bg-gray-50 rounded-2xl p-4 flex gap-3"
                >
                  <ImageWithFallback
                    src={similar.image}
                    alt={similar.name}
                    className="w-24 h-24 object-cover rounded-xl flex-shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="mb-1 line-clamp-2">{similar.name}</h4>
                    <span className="text-sm text-gray-600">{similar.price} ₽</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Main item name */}
        <div className="px-6 py-6">
          <h1 className="mb-6">{item.name}</h1>

          {/* Description */}
          <p className="text-gray-600 mb-4">{item.description}</p>

          {/* Weight */}
          {item.weight && (
            <div className="mb-4">
              <span className="text-sm text-gray-500">Вес: </span>
              <span>{item.weight}</span>
            </div>
          )}

          {/* Nutrition info */}
          {item.calories && item.nutrients && (
            <div className="bg-gray-50 rounded-2xl p-6 mb-4">
              <p className="text-gray-600 text-sm mb-2">пищевая ценность</p>
              <div className="mb-4">
                {item.calories} ккал
              </div>
              
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <p className="text-gray-600 text-sm mb-1">белки</p>
                  <span>{item.nutrients.proteins} г</span>
                </div>
                <div>
                  <p className="text-gray-600 text-sm mb-1">жиры</p>
                  <span>{item.nutrients.fats} г</span>
                </div>
                <div>
                  <p className="text-gray-600 text-sm mb-1">углеводы</p>
                  <span>{item.nutrients.carbs} г</span>
                </div>
              </div>
            </div>
          )}

          {/* Allergens */}
          {item.allergens && item.allergens.length > 0 && (
            <div className="mb-4 p-4 bg-orange-50 rounded-xl">
              <p className="text-sm text-orange-800">
                <strong>Содержит аллергены:</strong> {item.allergens.join(', ')}
              </p>
            </div>
          )}

          {/* Composition button */}
          <Button
            variant="outline"
            onClick={() => setShowComposition(!showComposition)}
            className="w-full mt-4 h-12 rounded-full border-2 border-gray-200 text-blue-600 hover:bg-blue-50"
          >
            Состав
          </Button>

          {showComposition && (
            <div className="mt-4 p-4 bg-blue-50 rounded-2xl">
              <p className="text-gray-700 mb-2">
                <strong>Ингредиенты:</strong>
              </p>
              <p className="text-gray-700">
                {item.ingredients ? item.ingredients.join(', ') : 'Подробный состав блюда доступен у персонала.'}
              </p>
            </div>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}
